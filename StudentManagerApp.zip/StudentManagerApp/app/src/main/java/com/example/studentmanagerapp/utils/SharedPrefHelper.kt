package com.example.studentmanagerapp.utils

import android.content.Context
import android.content.SharedPreferences

class SharedPrefHelper(context: Context) {
    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

    fun saveFavoriteColor(color: String) {
        sharedPreferences.edit().putString("favoriteColor", color).apply()
    }

    fun getFavoriteColor(): String? {
        return sharedPreferences.getString("favoriteColor", "")
    }
}
