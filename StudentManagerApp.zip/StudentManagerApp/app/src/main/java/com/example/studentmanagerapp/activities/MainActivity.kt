package com.example.studentmanagerapp.activities

import android.content.SharedPreferences
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.studentmanagerapp.R

class MainActivity : AppCompatActivity(){
    private lateinit var etName: EditText
    private lateinit var etPhone: EditText
    private lateinit var etFavCol: EditText
    private lateinit var btnAdd: Button
    private lateinit var btnViewAll: Button
    private lateinit var btnSaveCol: Button
    private lateinit var btnShowCol: Button
    private lateinit var sharedPreferences : SharedPreferences
    private lateinit var db: SQLiteDatabase


    override fun  onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.youtube)

        etName = findViewById(R.id.etName)
        etPhone = findViewById(R.id.etPhone)
        etFavCol = findViewById(R.id.etFavCol)
        btnAdd = findViewById(R.id.btnAdd)
        btnViewAll = findViewById(R.id.btnViewAll)
        btnSaveCol = findViewById(R.id.btnSaveCol)
        btnShowCol = findViewById(R.id.btnShowCol)


        sharedPreferences = getSharedPreferences("UserPref", MODE_PRIVATE)
        db = openOrCreateDatabase("friendDB", MODE_PRIVATE, null)
        db.execSQL("CREATE TABLE IF NOT EXISTS friend(name VARCHAR, phone VARCHAR PRIMARY KEY)")

        btnAdd.setOnClickListener {
            val name = etName.text.toString()
            val phone = etPhone.text.toString()
            if (name.isEmpty() || phone.isEmpty()) {
                showToast("Masukkan Nama dan Nomor Telp!")
                return@setOnClickListener
            }
            db.execSQL("INSERT INTO friends VALUES('$name','$phone')")
            showToast("Teman baru berhadil ditambahkan!")
            clearTextFields()
        }

        btnViewAll.setOnClickListener {
            val cursor: Cursor = db.rawQuery("SELECT*FROM friends", null)
            if (cursor.count == 0) {
                showToast("Daftar teman Kosong atau tidak ditemukan!")
                return@setOnClickListener
            }
            val buffer = StringBuilder()
            while (cursor.moveToNext()) {
                buffer.append("Name: ${cursor.getString(0)}\n")
                buffer.append("Phone:${cursor.getString(1)}\n\n")
            }
            showMessage("Daftar Teman", buffer.toString())
            cursor.close()
        }

        btnSaveCol.setOnClickListener {
            val color = etFavCol.text.toString()
            if (color.isEmpty()) {
                showToast("Masukkan Warna Favorite")
                return@setOnClickListener
            }
            sharedPreferences.edit().putString("warnaFavorite", color).apply()
            showToast(" Warva Favorite Berhasil disimpan!")
        }

        btnShowCol.setOnClickListener {
            val color = sharedPreferences.getString("warnaFavorite", "Tidak ada warna disimpan")
            showMessage("Warna Favorite", "Warna Favorite: $color")
        }
    }

    private fun showMessage(title: String, message: String) {
        android.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setCancelable(true)
            .show()
    }
    private fun showToast(message:String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
    private fun clearTextFields(){
        etName.text.clear()
        etPhone.text.clear()
        etFavCol.text.clear()
    }

}
