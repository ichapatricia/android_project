package com.example.mynote_app.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mynote_app.R
import com.example.mynote_app.data.Note
import com.google.android.material.floatingactionbutton.FloatingActionButton

class NoteListFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_note_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerView: RecyclerView = view.findViewById(R.id.recyclerViewNotes)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        // Adapter akan diimplementasikan nanti
        // Contoh daftar catatan sementara
        val notes = listOf(
            Note(1, "Catatan Pertama", "Isi catatan pertama"),
            Note(2, "Catatan Kedua", "Isi catatan kedua"),
            Note(3, "Catatan Ketiga", "Isi catatan ketiga")
        )

        val btnAdd: FloatingActionButton = view.findViewById(R.id.fab_add)

        btnAdd.setOnClickListener {
            findNavController().navigate(R.id.action_noteListFragment_to_addNoteFragment)

        }

        // Gunakan adapter dengan listener klik
        recyclerView.adapter = NoteAdapter(notes) { note ->
            val bundle = Bundle().apply {
                putString("noteTitle", note.title)
                putString("noteContent", note.content)
            }

            findNavController().navigate(R.id.action_noteListFragment_to_notesDetailFragment, bundle)
        }
    }
}