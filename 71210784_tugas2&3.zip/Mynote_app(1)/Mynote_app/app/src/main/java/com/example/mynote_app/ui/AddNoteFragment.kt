package com.example.mynote_app.ui

import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.mynote_app.R
import com.example.mynote_app.data.Note
import com.example.mynote_app.data.NoteDao
import com.example.mynote_app.data.NoteDatabase
import kotlinx.coroutines.launch

class AddNoteFragment : Fragment() {

    private lateinit var noteDao: NoteDao

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_add_note, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        noteDao = NoteDatabase.getDatabase(requireContext()).noteDao()

        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                findNavController().navigateUp()
            }
        })

        val buttonSave: Button = view.findViewById(R.id.buttonSaveNote)
        val editTextTitle: EditText = view.findViewById(R.id.editTextNoteTitle)
        val editTextContent: EditText = view.findViewById(R.id.editTextNoteContent)

        buttonSave.setOnClickListener {
            val title = editTextTitle.text.toString()
            val content = editTextContent.text.toString()
            addNoteToDatabase(title, content)
        }
    }

    private fun addNoteToDatabase(title: String, content: String) {
        val note = Note(0, title, content)
        lifecycleScope.launch {
            noteDao.insert(note)
            findNavController().navigateUp()
        }
    }
}