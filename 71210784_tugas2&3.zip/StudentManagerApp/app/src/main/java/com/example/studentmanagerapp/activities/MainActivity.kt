package com.example.studentmanagerapp.activities


import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.studentmanagerapp.R

class MainActivity : AppCompatActivity(){
    private lateinit var etName: EditText
    private lateinit var etPhone: EditText
    private lateinit var etFavCol: EditText
    private lateinit var btnAdd: Button
    private lateinit var btnViewAll: Button
    private lateinit var btnSaveCol: Button
    private lateinit var btnShowCol: Button
    private lateinit var db: SQLiteDatabase


    override fun  onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.youtube)

        etName = findViewById(R.id.etName)
        etPhone = findViewById(R.id.etPhone)
        etFavCol = findViewById(R.id.etFavCol)
        btnAdd = findViewById(R.id.btnAdd)
        btnViewAll = findViewById(R.id.btnViewAll)
        btnSaveCol = findViewById(R.id.btnSaveCol)
        btnShowCol = findViewById(R.id.btnShowCol)



        db = openOrCreateDatabase("friendDB", MODE_PRIVATE, null)
        db.execSQL("CREATE TABLE IF NOT EXISTS friends(name VARCHAR, phone VARCHAR PRIMARY KEY, favorite_color VARCHAR)")

        btnAdd.setOnClickListener {
            val name = etName.text.toString()
            val phone = etPhone.text.toString()
            if (name.isEmpty() || phone.isEmpty()) {
                showToast("Masukkan Nama dan Nomor Telp!")
                return@setOnClickListener
            }
            db.execSQL("INSERT INTO friends (name, phone, favorite_color)VALUES(?, ?, ?)", arrayOf(name,phone,""))
            showToast("Teman baru berhadil ditambahkan!")
            clearTextFields()
        }

        btnViewAll.setOnClickListener {
            val cursor: Cursor = db.rawQuery("SELECT*FROM friends", null)
            if (cursor.count == 0) {
                showToast("Daftar teman Kosong atau tidak ditemukan!")
                return@setOnClickListener
            }
            val buffer = StringBuilder()
            while (cursor.moveToNext()) {
                buffer.append("Name: ${cursor.getString(0)}\n")
                buffer.append("Phone:${cursor.getString(1)}\n\n")
                buffer.append("Warna Favorite:${cursor.getString(2)}\n\n")
            }
            showMessage("Daftar Teman", buffer.toString())
            cursor.close()
        }

        btnSaveCol.setOnClickListener {
            val phone=etPhone.text.toString()
            val color = etFavCol.text.toString()

            if (phone.isEmpty() || color.isEmpty()) {
                showToast("Masukkan Nomor Telepon dan Warna Favorite")
                return@setOnClickListener
            }

            val cursor = db.rawQuery("SELECT name FROM friends WHERE phone = ?", arrayOf(phone))
            if (cursor.moveToFirst()) {
                val name = cursor.getString(0) // Ambil nama dari database
                cursor.close()

                db.execSQL("UPDATE friends SET favorite_color = ? WHERE phone = ?", arrayOf(color, phone))
                showToast("Warna Favorit untuk $name berhasil disimpan!")
            }else{
                showToast("Nomor telepon tidak ditemukan!")
                cursor.close()
            }
        }

        btnShowCol.setOnClickListener {
            val phone= etPhone.text.toString()
            if(phone.isEmpty()){
                showToast("Masukkan Nomor Telepon!")
                return@setOnClickListener
            }

            val cursor = db.rawQuery("SELECT name, favorite_color FROM friends WHERE phone = ?", arrayOf(phone))
            if (cursor.moveToFirst()){
                val name = cursor.getString(0)
                val color = cursor.getString(1)

                showMessage("Informasi Teman", "Nama: $name\nWarna Favorite: ${if(color.isEmpty())"Belum diset" else color}")
            }else{
                showToast("Nomor Telepon tidak ditemukan")
            }
            cursor.close()
        }
    }

    private fun showMessage(title: String, message: String) {
        android.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setCancelable(true)
            .show()
    }
    private fun showToast(message:String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
    private fun clearTextFields(){
        etName.text.clear()
        etPhone.text.clear()
        etFavCol.text.clear()
    }

}
